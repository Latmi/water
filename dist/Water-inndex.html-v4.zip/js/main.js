const swiper = new Swiper('.projects__swiper', {
    // Optional parameters
    direction: 'horizontal',
    loop: false,

    // Navigation arrows
    navigation: {
        nextEl: '.projects .slider-arrow--next',
        prevEl: '.projects .slider-arrow--prev',
    },
});

const swiperNews = new Swiper('.news__swiper', {
    // Optional parameters
    direction: 'horizontal',
    loop: false,
    slidesPerView: "auto",
    spaceBetween: 40,

    // Navigation arrows
    navigation: {
        nextEl: '.news .slider-arrow--next',
        prevEl: '.news .slider-arrow--prev',
    },
});